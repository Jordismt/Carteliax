import { randomUUID } from "node:crypto";

import { supabaseAdmin } from "../../infrastructure/database/supabase.js";

import { stripe, PRICE_ID, FRONTEND_URL } from "./stripeService.js";

// ==========================================
// CONFIGURACIÓN
// ==========================================

const CHECKOUT_DURATION_SECONDS = 30 * 60;

const BLOCKED_STATUSES = new Set(["active", "trialing", "past_due", "unpaid", "paused", "incomplete"]);

// ==========================================
// ERRORES
// ==========================================

function respondError(res, error) {
  console.error("[SUBSCRIPTIONS]", error);

  return res.status(500).json({
    success: false,
    message: "No se pudo procesar la solicitud.",
  });
}

// ==========================================
// VALIDAR IDENTIFICADOR
// ==========================================

function validBusinessId(value) {
  return (
    typeof value === "string" &&
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)
  );
}

// ==========================================
// VERIFICAR PROPIETARIO
// ==========================================

async function ownedBusiness(userId, businessId) {
  const { data, error } = await supabaseAdmin
    .from("businesses")
    .select("id, name, owner_id")
    .eq("id", businessId)
    .eq("owner_id", userId)
    .maybeSingle();

  if (error) {
    throw error;
  }

  return data;
}

// ==========================================
// CONSULTAR SUSCRIPCIÓN EN SUPABASE
// ==========================================

async function findSubscription(businessId) {
  const { data, error } = await supabaseAdmin
    .from("subscriptions")
    .select("*")
    .eq("business_id", businessId)
    .maybeSingle();

  if (error) {
    throw error;
  }

  return data;
}

// ==========================================
// CONSULTAR ESTADO ACTUAL EN STRIPE
// ==========================================

async function retrieveRemoteSubscription(existing) {
  if (!existing?.stripe_subscription_id) {
    return null;
  }

  return stripe.subscriptions.retrieve(existing.stripe_subscription_id);
}

// ==========================================
// OBTENER SUSCRIPCIÓN
// GET /api/subscriptions/:businessId
// ==========================================

export async function getSubscription(req, res) {
  try {
    const { businessId } = req.params;

    if (!validBusinessId(businessId)) {
      return res.status(400).json({
        success: false,
        message: "Identificador de restaurante inválido.",
      });
    }

    const business = await ownedBusiness(req.user.id, businessId);

    if (!business) {
      return res.status(403).json({
        success: false,
        message: "No eres propietario del restaurante.",
      });
    }

    const subscription = await findSubscription(businessId);

    if (!subscription) {
      return res.json({
        success: true,
        subscription: null,
      });
    }

    // Solo devolvemos los datos que necesita
    // el frontend. Nunca devolvemos claves
    // privadas ni datos de tarjetas.

    return res.json({
      success: true,

      subscription: {
        id: subscription.id,
        business_id: subscription.business_id,
        status: subscription.status,

        stripe_customer_id: subscription.stripe_customer_id,

        stripe_subscription_id: subscription.stripe_subscription_id,

        trial_ends_at: subscription.trial_ends_at,

        trial_used_at: subscription.trial_used_at,

        current_period_end: subscription.current_period_end,

        cancel_at_period_end: subscription.cancel_at_period_end,

        checkout_expires_at: subscription.checkout_expires_at,
        checkout_session_id: subscription.checkout_session_id,
      },
    });
  } catch (error) {
    return respondError(res, error);
  }
}

// ==========================================
// CREAR CHECKOUT
// POST /api/subscriptions/checkout
// ==========================================

export async function createCheckout(req, res) {
  let reservedAttempt = null;
  let checkoutCreated = false;

  try {
    const { businessId } = req.body ?? {};

    if (!validBusinessId(businessId)) {
      return res.status(400).json({
        success: false,
        message: "Identificador de restaurante inválido.",
      });
    }

    // ======================================
    // 1. VERIFICAR PROPIETARIO
    // ======================================

    const business = await ownedBusiness(req.user.id, businessId);

    if (!business) {
      return res.status(403).json({
        success: false,
        message: "No eres propietario del restaurante.",
      });
    }

    // ======================================
    // 2. CONSULTAR SUSCRIPCIÓN EXISTENTE
    // ======================================

    const existing = await findSubscription(businessId);

    // ======================================
    // 3. COMPROBAR SUSCRIPCIÓN EN STRIPE
    // ======================================

    const remote = await retrieveRemoteSubscription(existing);

    if (remote && BLOCKED_STATUSES.has(remote.status)) {
      return res.status(409).json({
        success: false,
        message: "Ya existe una suscripción. Gestiona la actual desde facturación.",
      });
    }

    // ======================================
    // 4. COMPROBAR CHECKOUT PENDIENTE
    // ======================================

    if (
      existing?.status === "checkout_pending" &&
      existing.checkout_expires_at &&
      new Date(existing.checkout_expires_at).getTime() > Date.now()
    ) {
      return res.status(409).json({
        success: false,
        message:
          "Ya existe un proceso de contratación pendiente. Espera a que caduque antes de intentarlo de nuevo.",
      });
    }

    // ======================================
    // 5. RESERVAR INTENTO
    // ======================================

    const attemptId = randomUUID();

    const expiresAt = Math.floor(Date.now() / 1000) + CHECKOUT_DURATION_SECONDS;

    // Guardamos el intento para evitar
    // contrataciones secuenciales duplicadas.
    //
    // Esta reserva no es atómica.
    // Antes de producción se debe sustituir
    // por una operación transaccional.

    const { error: reserveError } = await supabaseAdmin.from("subscriptions").upsert(
      {
        business_id: businessId,
        status: "checkout_pending",
        checkout_attempt_id: attemptId,
        checkout_expires_at: new Date(expiresAt * 1000).toISOString(),
        checkout_session_id: null,
      },
      {
        onConflict: "business_id",
      },
    );

    if (reserveError) {
      throw reserveError;
    }

    reservedAttempt = {
      businessId,
      attemptId,
      previousStatus: existing?.status ?? "inactive",
    };

    // ======================================
    // 6. COMPROBAR PRUEBA GRATUITA
    // ======================================

    const trialAllowed = !existing?.trial_used_at;

    // ======================================
    // 7. REUTILIZAR CLIENTE DE STRIPE
    // ======================================

    const customerOptions = existing?.stripe_customer_id
      ? {
          customer: existing.stripe_customer_id,
        }
      : {
          customer_email: req.user.email || undefined,
        };

    // No se puede enviar customer_email
    // cuando se reutiliza customer.

    // ======================================
    // 8. CREAR SESIÓN DE STRIPE
    // ======================================

    const session = await stripe.checkout.sessions.create(
      {
        mode: "subscription",

        ...customerOptions,

        client_reference_id: businessId,

        line_items: [
          {
            price: PRICE_ID,
            quantity: 1,
          },
        ],

        payment_method_collection: "always",

        subscription_data: {
          ...(trialAllowed
            ? {
                trial_period_days: 7,
              }
            : {}),

          metadata: {
            business_id: businessId,
            owner_id: req.user.id,
          },
        },

        metadata: {
          business_id: businessId,
          owner_id: req.user.id,
          checkout_attempt_id: attemptId,
        },

        success_url: `${FRONTEND_URL}/billing/${businessId}?checkout=success`,

        cancel_url: `${FRONTEND_URL}/billing/${businessId}?checkout=cancelled`,

        expires_at: expiresAt,
      },
      {
        idempotencyKey: `checkout_${businessId}_${attemptId}`,
      },
    );

    if (!session.url) {
      throw new Error("Stripe no ha devuelto la URL de Checkout.");
    }

    checkoutCreated = true;

    // Persistir la sesión para poder recuperarla o caducarla al volver.
    const { error: saveSessionError } = await supabaseAdmin
      .from("subscriptions")
      .update({ checkout_session_id: session.id })
      .eq("business_id", businessId)
      .eq("checkout_attempt_id", attemptId);
    if (saveSessionError) throw saveSessionError;

    return res.json({
      success: true,
      url: session.url,
    });
  } catch (error) {
    console.error("[CHECKOUT ERROR]", error);

    // Solo revertimos la reserva si no se
    // ha creado una sesión de Stripe.
    //
    // Si la sesión se creó pero hubo un
    // error de comunicación, dejamos que
    // expire para evitar duplicados.

    if (reservedAttempt && !checkoutCreated) {
      try {
        const { data: current } = await supabaseAdmin
          .from("subscriptions")
          .select("checkout_attempt_id, stripe_subscription_id")
          .eq("business_id", reservedAttempt.businessId)
          .maybeSingle();

        if (current?.checkout_attempt_id === reservedAttempt.attemptId && !current.stripe_subscription_id) {
          const { error: cleanupError } = await supabaseAdmin
            .from("subscriptions")
            .update({
              status: reservedAttempt.previousStatus,
              checkout_attempt_id: null,
              checkout_expires_at: null,
              checkout_session_id: null,
            })
            .eq("business_id", reservedAttempt.businessId)
            .eq("checkout_attempt_id", reservedAttempt.attemptId);

          if (cleanupError) {
            console.error("[CHECKOUT CLEANUP ERROR]", cleanupError);
          }
        }
      } catch (cleanupError) {
        console.error("[CHECKOUT CLEANUP ERROR]", cleanupError);
      }
    }

    return respondError(res, error);
  }
}

// Cancelar o recuperar un intento de Checkout sin bloquear al cliente.
export async function cancelPendingCheckout(req, res) {
  try {
    const { businessId } = req.body ?? {};
    if (!validBusinessId(businessId)) {
      return res.status(400).json({ success: false, message: "Restaurante inválido." });
    }
    const business = await ownedBusiness(req.user.id, businessId);
    if (!business) return res.status(403).json({ success: false, message: "No autorizado." });
    const existing = await findSubscription(businessId);
    if (!existing || existing.status !== "checkout_pending") {
      return res.json({ success: true });
    }
    if (existing.stripe_subscription_id) {
      const remote = await stripe.subscriptions.retrieve(existing.stripe_subscription_id);
      if (BLOCKED_STATUSES.has(remote.status)) {
        return res.status(409).json({ success: false, message: "La suscripción ya existe. Actualiza la página." });
      }
    }
    if (existing.checkout_session_id) {
      const session = await stripe.checkout.sessions.retrieve(existing.checkout_session_id);
      if (session.status === "complete") {
        return res.status(409).json({ success: false, message: "Stripe ha completado el Checkout. Actualiza el estado." });
      }
      if (session.status === "open") {
        await stripe.checkout.sessions.expire(session.id);
      }
    } else {
      // Intentos antiguos sin ID de sesión: esperar su caducidad para
      // evitar que una URL antigua y una nueva puedan pagarse a la vez.
      if (existing.checkout_expires_at && new Date(existing.checkout_expires_at).getTime() > Date.now()) {
        return res.status(409).json({ success: false, message: "Este intento antiguo no se puede cancelar con seguridad. Podrás volver a contratar cuando caduque." });
      }
    }
    const { error } = await supabaseAdmin.from("subscriptions")
      .update({ status: "inactive", checkout_attempt_id: null, checkout_expires_at: null, checkout_session_id: null })
      .eq("business_id", businessId)
      .eq("status", "checkout_pending")
      .eq("checkout_attempt_id", existing.checkout_attempt_id);
    if (error) throw error;
    return res.json({ success: true });
  } catch (error) {
    return respondError(res, error);
  }
}

// ==========================================
// PORTAL DE FACTURACIÓN
// POST /api/subscriptions/portal
// ==========================================

export async function createPortal(req, res) {
  try {
    const { businessId } = req.body ?? {};

    if (!validBusinessId(businessId)) {
      return res.status(400).json({
        success: false,
        message: "Identificador de restaurante inválido.",
      });
    }

    // ======================================
    // 1. VERIFICAR PROPIETARIO
    // ======================================

    const business = await ownedBusiness(req.user.id, businessId);

    if (!business) {
      return res.status(403).json({
        success: false,
        message: "No eres propietario del restaurante.",
      });
    }

    // ======================================
    // 2. OBTENER CLIENTE DE STRIPE
    // ======================================

    const existing = await findSubscription(businessId);

    if (!existing?.stripe_customer_id) {
      return res.status(404).json({
        success: false,
        message: "Todavía no existe una cuenta de facturación para este restaurante.",
      });
    }

    // ======================================
    // 3. CREAR SESIÓN DEL PORTAL
    // ======================================

    const session = await stripe.billingPortal.sessions.create({
      customer: existing.stripe_customer_id,

      return_url: `${FRONTEND_URL}/billing/${businessId}`,
    });

    return res.json({
      success: true,
      url: session.url,
    });
  } catch (error) {
    return respondError(res, error);
  }
}

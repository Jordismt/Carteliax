import { supabaseAdmin } from "../../infrastructure/database/supabase.js";

import { stripe, stripeDate } from "./stripeService.js";

// ==========================================
// CONFIGURACIÓN
// ==========================================

const HANDLED_EVENTS = new Set([
  "checkout.session.completed",
  "customer.subscription.created",
  "customer.subscription.updated",
  "customer.subscription.deleted",
]);

// ==========================================
// OBTENER ID DEL CLIENTE
// ==========================================

function getCustomerId(customer) {
  if (typeof customer === "string") {
    return customer;
  }

  return customer?.id ?? null;
}

// ==========================================
// SINCRONIZAR SUSCRIPCIÓN
// ==========================================

async function syncSubscription(subscription) {
  const businessId = subscription.metadata?.business_id;

  if (!businessId) {
    throw new Error(`La suscripción ${subscription.id} no tiene business_id.`);
  }

  // ======================================
  // 1. CONSULTAR ESTADO ANTERIOR
  // ======================================

  const { data: existing, error: readError } = await supabaseAdmin
    .from("subscriptions")
    .select("trial_used_at, stripe_subscription_id")
    .eq("business_id", businessId)
    .maybeSingle();

  if (readError) {
    throw readError;
  }

  // ======================================
  // 2. OBTENER FECHAS
  // ======================================

  const periodEnds =
    subscription.items?.data?.[0]?.current_period_end ?? subscription.current_period_end ?? null;

  const trialEnd = subscription.trial_end ?? null;

  const customerId = getCustomerId(subscription.customer);

  if (!customerId) {
    throw new Error(`La suscripción ${subscription.id} no tiene cliente de Stripe.`);
  }

  // ======================================
  // 3. PREPARAR DATOS
  // ======================================

  const payload = {
    business_id: businessId,

    stripe_customer_id: customerId,

    stripe_subscription_id: subscription.id,

    status: subscription.status,

    trial_ends_at: stripeDate(trialEnd),

    current_period_end: stripeDate(periodEnds),

    cancel_at_period_end: Boolean(subscription.cancel_at_period_end),

    checkout_attempt_id: null,

    checkout_expires_at: null,
    checkout_session_id: null,

    // Una prueba utilizada no puede
    // concederse de nuevo.

    ...(trialEnd && !existing?.trial_used_at
      ? {
          trial_used_at: new Date().toISOString(),
        }
      : {}),
  };

  // ======================================
  // 4. ACTUALIZAR SUPABASE
  // ======================================

  const { error } = await supabaseAdmin.from("subscriptions").upsert(payload, {
    onConflict: "business_id",
  });

  if (error) {
    throw error;
  }
}

// ==========================================
// CONSULTAR SUSCRIPCIÓN ACTUAL
// ==========================================

async function retrieveCurrentSubscription(subscriptionId) {
  try {
    return await stripe.subscriptions.retrieve(subscriptionId);
  } catch (error) {
    // Una suscripción eliminada o
    // inaccesible puede no recuperarse.
    // No ocultamos otros errores de Stripe.

    if (error?.statusCode === 404) {
      return null;
    }

    throw error;
  }
}

// ==========================================
// PROCESAR CHECKOUT
// ==========================================

async function handleCheckoutCompleted(session) {
  if (session.mode !== "subscription" || !session.subscription) {
    return;
  }

  const subscriptionId =
    typeof session.subscription === "string" ? session.subscription : session.subscription.id;

  const subscription = await retrieveCurrentSubscription(subscriptionId);

  if (!subscription) {
    throw new Error(`No se pudo recuperar la suscripción ${subscriptionId}.`);
  }

  // Comprobar que la sesión y la
  // suscripción pertenecen al mismo
  // establecimiento.

  const sessionBusinessId = session.metadata?.business_id ?? session.client_reference_id;

  const subscriptionBusinessId = subscription.metadata?.business_id;

  if (!sessionBusinessId || sessionBusinessId !== subscriptionBusinessId) {
    throw new Error("Los identificadores del restaurante no coinciden.");
  }

  await syncSubscription(subscription);
}

// ==========================================
// PROCESAR CAMBIOS DE SUSCRIPCIÓN
// ==========================================

async function handleSubscriptionEvent(event) {
  const snapshot = event.data.object;

  if (!snapshot?.id) {
    throw new Error("El evento no contiene una suscripción válida.");
  }

  // Consultamos el estado actual de
  // Stripe para reducir los problemas
  // de eventos fuera de orden.

  const current = await retrieveCurrentSubscription(snapshot.id);

  if (current) {
    await syncSubscription(current);
    return;
  }

  // Si Stripe devuelve 404 y se trata
  // de una eliminación, conservamos
  // el estado del evento recibido.

  if (event.type === "customer.subscription.deleted") {
    await syncSubscription(snapshot);
    return;
  }

  throw new Error(`No se pudo recuperar la suscripción ${snapshot.id}.`);
}

// ==========================================
// WEBHOOK DE STRIPE
// POST /api/subscriptions/webhook
// ==========================================

export async function stripeWebhook(req, res) {
  let event;

  // ======================================
  // 1. VERIFICAR FIRMA
  // ======================================

  try {
    const signature = req.headers["stripe-signature"];

    if (!signature) {
      return res.status(400).json({
        success: false,
        message: "Falta la firma de Stripe.",
      });
    }

    event = stripe.webhooks.constructEvent(req.body, signature, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (error) {
    console.error("[STRIPE SIGNATURE ERROR]", error.message);

    return res.status(400).json({
      success: false,
      message: "Firma de Stripe inválida.",
    });
  }

  // ======================================
  // 2. PROCESAR EVENTO
  // ======================================

  try {
    // Ignorar eventos que no necesitamos.

    if (!HANDLED_EVENTS.has(event.type)) {
      return res.json({
        received: true,
      });
    }

    // ====================================
    // COMPROBAR DUPLICADOS
    // ====================================

    const { data: already, error: readError } = await supabaseAdmin
      .from("stripe_webhook_events")
      .select("id")
      .eq("id", event.id)
      .maybeSingle();

    if (readError) {
      throw readError;
    }

    if (already) {
      return res.json({
        received: true,
      });
    }

    // ====================================
    // CHECKOUT COMPLETADO
    // ====================================

    if (event.type === "checkout.session.completed") {
      await handleCheckoutCompleted(event.data.object);
    }

    // ====================================
    // SUSCRIPCIONES
    // ====================================

    if (
      event.type === "customer.subscription.created" ||
      event.type === "customer.subscription.updated" ||
      event.type === "customer.subscription.deleted"
    ) {
      await handleSubscriptionEvent(event);
    }

    // ====================================
    // REGISTRAR EVENTO PROCESADO
    // ====================================

    const { error: insertError } = await supabaseAdmin.from("stripe_webhook_events").insert({
      id: event.id,
      event_type: event.type,
    });

    // Stripe puede reenviar un evento
    // que otro proceso ya registró.

    if (insertError && insertError.code !== "23505") {
      throw insertError;
    }

    return res.json({
      received: true,
    });
  } catch (error) {
    console.error("[STRIPE WEBHOOK ERROR]", {
      eventId: event?.id,
      eventType: event?.type,
      error,
    });

    // Stripe reintentará el evento
    // cuando devolvemos un error 500.

    return res.status(500).json({
      received: false,
    });
  }
}

import Stripe from "stripe";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("Falta STRIPE_SECRET_KEY.");
}

if (!process.env.STRIPE_PRICE_ID) {
  throw new Error("Falta STRIPE_PRICE_ID.");
}

if (!process.env.FRONTEND_URL) {
  throw new Error("Falta FRONTEND_URL.");
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export const PRICE_ID = process.env.STRIPE_PRICE_ID;

export const FRONTEND_URL = process.env.FRONTEND_URL.replace(/\/$/, "");

// Convierte fechas UNIX de Stripe a fechas ISO.
export function stripeDate(unix) {
  return typeof unix === "number" ? new Date(unix * 1000).toISOString() : null;
}

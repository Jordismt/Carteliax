import "dotenv/config";

import { z } from "zod";

// ==========================================
// VALIDACIÓN DE VARIABLES DE ENTORNO
// ==========================================

const envSchema = z.object({
  // ========================================
  // SERVIDOR
  // ========================================

  MICROSITES_ENABLED: z.enum(["true", "false"]).default("false").transform(value => value === "true"),

  PORT: z.coerce.number().int().positive().default(5000),

  // Enable only after applying the additive translations migration.
  TRANSLATIONS_ENABLED: z.enum(["true", "false"]).default("false").transform((value) => value === "true"),
  GROQ_API_KEY: z.preprocess((value) => value === "" ? undefined : value, z.string().min(1).optional()),
  GROQ_TRANSLATION_MODEL: z.string().min(1).max(100).default("openai/gpt-oss-20b"),

  FRONTEND_URL: z.url(),

  // ========================================
  // SUPABASE
  // ========================================

  SUPABASE_URL: z.url(),

  SUPABASE_PUBLISHABLE_KEY: z.string().min(1),

  SUPABASE_SECRET_KEY: z.string().min(1),

  // ========================================
  // STRIPE
  // ========================================

  STRIPE_SECRET_KEY: z.string().startsWith("sk_test_"),

  STRIPE_WEBHOOK_SECRET: z.string().startsWith("whsec_"),

  STRIPE_PRICE_ID: z.string().startsWith("price_"),
});

// ==========================================
// EXPORTAR CONFIGURACIÓN VALIDADA
// ==========================================

export const env = envSchema.parse(process.env);

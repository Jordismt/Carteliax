<script setup lang="ts">
import {
  LayoutDashboard,
  Store,
  BookOpen,
  LogOut,
  Menu,
  X,
  ChevronRight,
} from "lucide-vue-next";

const route = useRoute();
const { logout } = useAuth();

const mobileMenuOpen = ref(false);
const loggingOut = ref(false);
const logoutError = ref("");
const mobileMenuButton = ref<HTMLButtonElement | null>(null);
const sidebar = ref<HTMLElement | null>(null);

const navigation = [
  {
    label: "Inicio",
    icon: LayoutDashboard,
    path: "/dashboard",
  },
  {
    label: "Establecimientos",
    icon: Store,
    path: "/businesses",
  },
  {
    label: "Cartas",
    icon: BookOpen,
    path: "/menus",
  },
];

const currentTitle = computed(() => {
  const path = route.path;

  if (path === "/dashboard") {
    return "Inicio";
  }

  if (path === "/businesses") {
    return "Mis establecimientos";
  }

  if (path.startsWith("/businesses/")) {
    return "Configurar establecimiento";
  }

  if (path === "/menus") {
    return "Mis cartas";
  }

  if (path.startsWith("/billing/")) return "Suscripción y facturación";
  if (path.endsWith("/design")) return "Personalizar carta";
  if (path.endsWith("/qr")) return "Código QR de la carta";
  if (path.endsWith("/languages")) return "Idiomas de la carta";

  if (path.startsWith("/menus/")) {
    return "Gestionar carta";
  }

  return "Carteliax";
});

const currentSection = computed(() => {
  if (route.path.startsWith("/billing/")) return "Facturación";

  if (route.path.startsWith("/businesses")) {
    return "Establecimientos";
  }

  if (route.path.startsWith("/menus")) {
    return "Cartas";
  }

  return "Inicio";
});

function isActive(path: string) {
  if (path === "/dashboard") {
    return route.path === path;
  }

  return route.path === path || route.path.startsWith(`${path}/`);
}

function trapMobileFocus(event: KeyboardEvent) {
  if (!mobileMenuOpen.value || !sidebar.value) return;
  const items = [...sidebar.value.querySelectorAll<HTMLElement>("a[href], button:not(:disabled)")].filter((item) => item.getClientRects().length);
  const first = items[0];
  const last = items.at(-1);
  if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
  else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
}

function closeMobileMenu() {
  mobileMenuOpen.value = false;
  if (import.meta.client) nextTick(() => mobileMenuButton.value?.focus());
}

async function handleLogout() {
  if (loggingOut.value) return;

  loggingOut.value = true;
  logoutError.value = "";

  try {
    await logout();
  } catch (error) {
    console.error("Error cerrando sesión:", error);
    logoutError.value = "No se pudo cerrar la sesión. Inténtalo de nuevo.";
    loggingOut.value = false;
  }
}

watch(
  () => route.fullPath,
  () => {
    closeMobileMenu();
  },
);

watch(mobileMenuOpen, (open) => {
  if (!import.meta.client) return;

  document.body.style.overflow = open ? "hidden" : "";
  if (open) nextTick(() => sidebar.value?.querySelector<HTMLButtonElement>("button")?.focus());
});

onUnmounted(() => {
  if (import.meta.client) {
    document.body.style.overflow = "";
  }
});
</script>

<template>
  <div class="workspace min-h-screen lg:flex" @keydown.esc="mobileMenuOpen && closeMobileMenu()">
    <a href="#workspace-content" class="skip-link">Ir al contenido</a>
    <!-- OVERLAY MÓVIL -->
    <Transition name="fade">
      <button
        v-if="mobileMenuOpen"
        type="button"
        aria-label="Cerrar navegación"
        class="fixed inset-0 z-40 bg-slate-950/45 lg:hidden"
        @click="closeMobileMenu" />
    </Transition>

    <!-- SIDEBAR -->
    <aside
      id="workspace-navigation"
      ref="sidebar"
      @keydown.tab="trapMobileFocus"
      class="fixed inset-y-0 left-0 z-50 flex w-64 max-w-[calc(100vw-3rem)] flex-col border-r border-slate-200 bg-white text-slate-900 shadow-lg transition-transform duration-300 ease-in-out lg:sticky lg:top-0 lg:h-screen lg:shrink-0 lg:translate-x-0 lg:shadow-none"
      :class="mobileMenuOpen ? 'translate-x-0' : '-translate-x-full max-lg:invisible'">
      <!-- MARCA -->
      <div class="flex h-16 shrink-0 items-center justify-between border-b border-slate-100 px-7">
        <NuxtLink
          to="/dashboard"
          class="group flex items-center gap-1 text-3xl font-black tracking-tight"
          @click="closeMobileMenu">
          Carteliax

          <span class="text-emerald-700 transition-transform "> . </span>
        </NuxtLink>

        <button
          type="button"
          aria-label="Cerrar menú"
          class="rounded-xl p-2 text-slate-600 transition hover:bg-slate-100 hover:text-slate-900 lg:hidden"
          @click="closeMobileMenu">
          <X :size="22" />
        </button>
      </div>

      <!-- CONTENIDO SCROLLABLE -->
      <div class="flex min-h-0 flex-1 flex-col overflow-y-auto">
        <!-- NAVEGACIÓN -->
        <div class="px-4 pt-5">
          <p class="mb-3 px-4 text-[11px] font-bold uppercase tracking-[0.2em] text-slate-500">
            Tu restaurante
          </p>

          <nav aria-label="Navegación principal" class="space-y-1.5">
            <template v-for="item in navigation" :key="item.path">
              <!-- OPCIÓN HABILITADA -->
              <NuxtLink
                :to="item.path"
                :aria-current="isActive(item.path) ? 'page' : undefined"
                class="group relative flex items-center gap-3 rounded-xl px-4 py-3.5 text-sm font-semibold transition-all duration-200"
                :class="
                  isActive(item.path)
                    ? 'bg-emerald-50 text-emerald-800'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                "
                @click="closeMobileMenu">
                <!-- INDICADOR ACTIVO -->
                <span
                  v-if="isActive(item.path)"
                  class="absolute bottom-2 left-0 top-2 w-1 rounded-r-full bg-emerald-600" />

                <component :is="item.icon" :size="20" :stroke-width="1.9" class="shrink-0" />

                <span class="flex-1">
                  {{ item.label }}
                </span>

                <ChevronRight v-if="isActive(item.path)" :size="16" class="text-emerald-700/70" />
              </NuxtLink>
            </template>
          </nav>
        </div>

        <!-- ESPACIADOR -->
        <div class="min-h-8 flex-1" />

        <!-- PIE DEL SIDEBAR -->
        <div class="shrink-0 border-t border-slate-200 px-5 py-5">
          <p v-if="logoutError" role="alert" class="mb-3 text-sm text-red-700">{{ logoutError }}</p>
          <button
            type="button"
            :disabled="loggingOut"
            class="flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold text-slate-600 transition hover:bg-red-500/10 hover:text-red-700 disabled:cursor-wait disabled:opacity-50"
            @click="handleLogout">
            <LogOut :size="19" />

            {{ loggingOut ? "Cerrando sesión..." : "Cerrar sesión" }}
          </button>
        </div>
      </div>
    </aside>

    <!-- CONTENIDO PRINCIPAL -->
    <main :inert="mobileMenuOpen || undefined" class="flex min-h-screen min-w-0 flex-1 flex-col pb-20 lg:pb-0">
      <!-- HEADER -->
      <header
        class="sticky top-0 z-30 flex h-16 shrink-0 items-center justify-between border-b border-slate-200 bg-white px-4 sm:px-9">
        <!-- IZQUIERDA -->
        <div class="flex min-w-0 items-center gap-4">
          <button
            type="button"
            ref="mobileMenuButton"
            aria-controls="workspace-navigation"
            aria-label="Abrir menú"
            :aria-expanded="mobileMenuOpen"
            class="rounded-xl border border-slate-200 p-2.5 text-slate-700 transition hover:bg-slate-50 lg:hidden"
            @click="mobileMenuOpen = true">
            <Menu :size="22" />
          </button>

          <div class="min-w-0">
            <div class="hidden items-center gap-2 text-xs font-medium text-slate-600 sm:flex">
              <span>Carteliax</span>

              <ChevronRight :size="12" />

              <span>
                {{ currentSection }}
              </span>
            </div>

            <p class="truncate text-base font-bold text-slate-950 sm:mt-1 sm:text-lg">
              {{ currentTitle }}
            </p>
          </div>
        </div>

      </header>

      <!-- CONTENIDO DINÁMICO -->
      <div id="workspace-content" tabindex="-1" class="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-8 sm:py-8" :inert="mobileMenuOpen || undefined">
        <slot />
      </div>

      <!-- FOOTER -->
      <footer class="hidden border-t border-slate-200 px-5 py-5 lg:block sm:px-9">
        <div
          class="mx-auto flex max-w-7xl flex-col gap-2 text-xs text-slate-600 sm:flex-row sm:items-center sm:justify-between">
          <span>
            © {{ new Date().getFullYear() }}
            Carteliax
          </span>

          <span> Tu carta digital, al día </span>
        </div>
      </footer>
    </main>
    <nav :inert="mobileMenuOpen || undefined" aria-label="Accesos principales" class="mobile-navigation fixed inset-x-0 bottom-0 z-30 grid grid-cols-3 border-t border-slate-200 bg-white lg:hidden">
      <NuxtLink v-for="item in navigation" :key="item.path" :to="item.path" :aria-current="isActive(item.path) ? 'page' : undefined" class="flex min-h-16 flex-col items-center justify-center gap-1 px-1 py-2 text-xs font-semibold" :class="isActive(item.path) ? 'text-emerald-800 bg-emerald-50' : 'text-slate-600'">
        <component :is="item.icon" :size="20" aria-hidden="true" />
        {{ item.label }}
      </NuxtLink>
    </nav>
  </div>
</template>

<style scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.25s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>

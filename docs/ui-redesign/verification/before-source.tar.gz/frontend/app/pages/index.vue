<script setup lang="ts">
import {
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  Check,
  ChevronDown,
  Clock3,
  Image,
  LayoutDashboard,
  Menu,
  Palette,
  QrCode,
  ShieldCheck,
  Smartphone,
  Store,
  UtensilsCrossed,
  X,
} from "lucide-vue-next";

const mobileOpen = ref(false);
const features = [
  {
    icon: BookOpen,
    title: "Cartas y categorías",
    text: "Crea y organiza tus cartas y sus categorías desde un único lugar.",
  },
  {
    icon: Image,
    title: "Platos que entran por los ojos",
    text: "Añade fotografías, descripciones y precios a cada producto.",
  },
  {
    icon: Palette,
    title: "Tu estilo, tu carta",
    text: "Personaliza el diseño para que represente a tu restaurante.",
  },
  {
    icon: QrCode,
    title: "Un QR, siempre actualizado",
    text: "Comparte tu carta con un QR sin reimprimirlo por cada cambio.",
  },
  {
    icon: ShieldCheck,
    title: "Información de alérgenos",
    text: "Gestiona la información de alérgenos de cada plato.",
  },
  {
    icon: LayoutDashboard,
    title: "Todo bajo control",
    text: "Edita platos, precios y disponibilidad desde tu panel.",
  },
];
const included = [
  "Panel de gestión",
  "Cartas y categorías",
  "Catálogo de productos reutilizables",
  "Fotografías, precios y descripciones",
  "Información de alérgenos",
  "Personalización del diseño",
  "Generación de códigos QR",
  "Gestión de disponibilidad",
  "Carta pública adaptada a móviles",
];
const faqs = [
  {
    q: "¿Tengo que saber programar o diseñar?",
    a: "No. Crea tu establecimiento, añade los platos y organiza tu carta desde el panel.",
  },
  {
    q: "¿Tengo que imprimir un QR nuevo cuando cambie los precios?",
    a: "No. El QR apunta a tu carta digital, que puedes actualizar desde el panel.",
  },
  {
    q: "¿Puedo incluir fotos y alérgenos?",
    a: "Sí. Puedes gestionar imágenes e información de alérgenos de tus platos.",
  },
  {
    q: "¿Cuánto cuesta?",
    a: "18 €/mes por establecimiento, con 7 días gratis si ese negocio no ha utilizado su prueba. Primero te registras y creas el establecimiento; después activas su suscripción con tarjeta en el pago seguro.",
  },
];
useSeoMeta({
  title: "Carteliax — Tu carta digital, a tu manera",
  description:
    "Crea y personaliza la carta QR de tu restaurante. Gestiona platos, precios, fotos y alérgenos. 7 días gratis.",
});
</script>

<template>
  <div class="site min-h-screen bg-white text-slate-900" @keydown.esc="mobileOpen = false">
    <header class="border-b border-slate-200">
      <nav aria-label="Navegación principal" class="mx-auto flex min-h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:px-8">
        <NuxtLink to="/" class="text-2xl font-semibold tracking-tight" aria-label="Carteliax inicio">Carteliax<span class="text-emerald-700">.</span></NuxtLink>
        <div class="hidden items-center gap-6 text-sm font-medium text-slate-600 md:flex">
          <a href="#como-funciona">Cómo funciona</a><a href="#funciones">Funciones</a><a href="#precio">Precio</a><a href="#faq">Preguntas</a>
        </div>
        <div class="flex items-center gap-2">
          <NuxtLink to="/login" class="site-secondary">Iniciar sesión</NuxtLink>
          <button type="button" class="site-secondary px-3 md:hidden" :aria-expanded="mobileOpen" aria-controls="site-navigation" :aria-label="mobileOpen ? 'Cerrar menú' : 'Abrir menú'" @click="mobileOpen = !mobileOpen"><X v-if="mobileOpen" :size="20" /><Menu v-else :size="20" /></button>
        </div>
      </nav>
      <nav v-if="mobileOpen" id="site-navigation" aria-label="Navegación móvil" class="grid gap-1 border-t border-slate-100 px-4 py-3 text-sm md:hidden">
        <a href="#como-funciona" @click="mobileOpen = false">Cómo funciona</a><a href="#funciones" @click="mobileOpen = false">Funciones</a><a href="#precio" @click="mobileOpen = false">Precio</a><a href="#faq" @click="mobileOpen = false">Preguntas</a>
        <NuxtLink to="/register" class="site-primary" @click="mobileOpen = false">Crear cuenta gratis</NuxtLink>
      </nav>
    </header>

    <main>
      <section class="mx-auto grid max-w-6xl items-center gap-10 px-4 py-12 sm:px-8 sm:py-20 lg:grid-cols-2">
        <div>
          <p class="text-sm font-semibold text-emerald-800">Cartas QR para restaurantes, bares y cafeterías</p>
          <h1 class="mt-4 text-4xl font-semibold leading-tight tracking-tight sm:text-5xl">Tu carta al día.<br />Sin complicaciones.</h1>
          <p class="mt-5 max-w-lg text-lg leading-8 text-slate-600">Cambia un precio, añade un plato o márcalo como agotado. Gestiona tu carta desde el móvil, mientras atiendes tu negocio.</p>
          <NuxtLink to="/register" class="site-primary mt-7">Crear cuenta gratis <ArrowRight :size="18" /></NuxtLink>
          <p class="mt-4 text-sm leading-6 text-slate-600">7 días gratis al activar la suscripción.<br />Después, 18 €/mes por establecimiento.</p>
        </div>
        <div class="rounded-xl border border-slate-200 bg-slate-50 p-5 sm:p-8" aria-label="Ejemplo de carta digital">
          <p class="text-xs font-medium text-slate-500">Ejemplo de carta digital</p>
          <div class="mt-4 rounded-lg border border-slate-200 bg-white p-5">
            <h2 class="text-2xl font-semibold">La Sobremesa</h2><p class="mt-1 text-sm text-slate-600">Cocina de casa, para compartir.</p>
            <div class="mt-6 border-t border-slate-100 pt-4"><h3 class="text-sm font-semibold text-emerald-800">Entrantes</h3>
              <div class="mt-4 flex items-start justify-between gap-4"><div><p class="font-semibold">Ensalada de la casa</p><p class="mt-1 text-sm text-slate-500">Ingredientes frescos, sabor de siempre.</p></div><span class="whitespace-nowrap font-semibold">9,50 €</span></div>
              <div class="mt-5 flex items-start justify-between gap-4 border-t border-slate-100 pt-4"><div><p class="font-semibold">Especial de la casa</p><p class="mt-1 text-sm text-slate-500">Nuestra receta para compartir.</p></div><span class="whitespace-nowrap font-semibold">12,00 €</span></div>
            </div>
          </div>
          <p class="mt-4 text-sm leading-6 text-slate-600">Tus clientes escanean el QR y consultan la carta desde su móvil.</p>
        </div>
      </section>

      <section id="como-funciona" class="border-y border-slate-200 bg-slate-50">
        <div class="mx-auto max-w-6xl px-4 py-12 sm:px-8">
          <h2 class="text-2xl font-semibold tracking-tight">De tu restaurante al móvil de tus clientes</h2>
          <ol class="mt-7 grid gap-6 md:grid-cols-3">
            <li v-for="(step, index) in [
              { title: 'Añade tu establecimiento', text: 'Crea tu cuenta y activa la suscripción de tu negocio.' },
              { title: 'Prepara tu carta', text: 'Organiza categorías, añade productos y elige el diseño.' },
              { title: 'Publica y comparte', text: 'Publica la carta y su diseño. Descarga el QR y colócalo en tus mesas.' },
            ]" :key="step.title" class="flex gap-3"><span class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-sm font-semibold text-emerald-800">{{ index + 1 }}</span><div><h3 class="font-semibold">{{ step.title }}</h3><p class="mt-2 text-sm leading-6 text-slate-600">{{ step.text }}</p></div></li>
          </ol>
        </div>
      </section>

      <section id="funciones" class="mx-auto max-w-6xl px-4 py-12 sm:px-8">
        <h2 class="text-2xl font-semibold tracking-tight">Lo que necesitas para gestionar tu carta</h2>
        <div class="mt-7 grid gap-x-10 gap-y-7 sm:grid-cols-2 lg:grid-cols-3">
          <div v-for="feature in features" :key="feature.title"><h3 class="font-semibold">{{ feature.title }}</h3><p class="mt-2 text-sm leading-6 text-slate-600">{{ feature.text }}</p></div>
        </div>
      </section>

      <section id="precio" class="border-y border-slate-200 bg-slate-50">
        <div class="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:px-8 md:grid-cols-2">
          <div><h2 class="text-2xl font-semibold tracking-tight">Un precio claro por establecimiento</h2><p class="mt-4 text-4xl font-semibold">18 € <span class="text-base font-normal text-slate-600">/mes</span></p><p class="mt-3 text-sm leading-6 text-slate-600">7 días gratis si ese establecimiento no ha utilizado su prueba. La tarjeta se solicita al activar la suscripción. Puedes gestionar la cancelación desde Facturación.</p><NuxtLink to="/register" class="site-primary mt-5">Crear cuenta gratis <ArrowRight :size="17" /></NuxtLink></div>
          <ul class="grid gap-3 text-sm text-slate-700"><li v-for="item in included" :key="item" class="flex items-center gap-2"><Check :size="17" class="shrink-0 text-emerald-700" />{{ item }}</li></ul>
        </div>
      </section>

      <section id="faq" class="mx-auto max-w-3xl px-4 py-12 sm:px-8">
        <h2 class="text-2xl font-semibold tracking-tight">Preguntas frecuentes</h2>
        <div class="mt-6 divide-y divide-slate-200"><details v-for="faq in faqs" :key="faq.q"><summary class="cursor-pointer py-4 text-base font-semibold">{{ faq.q }}</summary><p class="pb-5 text-sm leading-7 text-slate-600">{{ faq.a }}</p></details></div>
      </section>
    </main>
    <footer class="border-t border-slate-200"><div class="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-4 py-6 text-sm text-slate-500 sm:px-8"><span>© {{ new Date().getFullYear() }} Carteliax</span><NuxtLink to="/login" class="site-secondary">Acceder a mi cuenta</NuxtLink></div></footer>
  </div>
</template>

<style scoped>
.site-primary, .site-secondary { display: inline-flex; min-height: 44px; align-items: center; justify-content: center; gap: 8px; border-radius: 8px; padding: 10px 16px; font-size: 14px; font-weight: 600; }
.site-primary { background: #047857; color: white; }
.site-primary:hover { background: #065f46; }
.site-secondary { color: #334155; }
.site-secondary:hover { background: #f1f5f9; }
.site p, .site h1, .site h2, .site h3 { overflow-wrap: anywhere; }
#site-navigation > a { display: flex; min-height: 44px; align-items: center; padding-inline: 12px; }
.site section[id] { scroll-margin-top: 20px; }
</style>

<script setup lang="ts">
import { ArrowLeft, QrCode, AlertCircle, LoaderCircle } from "lucide-vue-next";

definePageMeta({
  middleware: "auth",
  layout: "dashboard",
});

useHead({
  title: "Generar QR | Carteliax",
});

interface Menu {
  id: string;
  business_id: string;
  name: string;
  slug: string;
  is_published: boolean;
}

interface Business {
  public_slug?: string;
  id: string;
  name: string;
  logo_url: string | null;
}

const route = useRoute();
const { apiFetch } = useApi();

const menuId = computed(() => String(route.params.id));

const menu = ref<Menu | null>(null);
const business = ref<Business | null>(null);

const loading = ref(true);
const errorMessage = ref("");

async function loadData() {
  loading.value = true;
  errorMessage.value = "";

  try {
    // Obtener carta
    const menuResponse = await apiFetch<{
      success: boolean;
      menu: Menu;
    }>(`/api/menus/${menuId.value}`);

    menu.value = menuResponse.menu;

    // Obtener establecimiento
    const businessResponse = await apiFetch<{
      success: boolean;
      business: Business;
    }>(`/api/businesses/${menuResponse.menu.business_id}`);

    business.value = businessResponse.business;
  } catch (error) {
    console.error(error);

    errorMessage.value = "No se pudieron cargar los datos de la carta.";
  } finally {
    loading.value = false;
  }
}

watch(menuId, loadData);

onMounted(loadData);
</script>

<template>
  <div class="ui-page mx-auto max-w-5xl">
    <!-- NAVEGACIÓN -->

    <NuxtLink
      :to="menu ? `/menus?business=${menu.business_id}` : '/menus'"
      class="inline-flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-emerald-700">
      <ArrowLeft :size="17" />
      Volver a mis cartas
    </NuxtLink>

    <section>
      <h1 class="ui-title">QR de tu carta</h1>
      <p class="ui-description">Descárgalo, imprímelo y colócalo en tu establecimiento.</p>
    </section>

    <!-- CARGANDO -->

    <div
      v-if="loading"
      class="flex items-center justify-center gap-3 rounded-2xl border border-slate-200 bg-white p-12 text-slate-500">
      <LoaderCircle :size="22" class="animate-spin text-emerald-600" />

      Cargando carta...
    </div>

    <!-- ERROR -->

    <div v-else-if="errorMessage" class="rounded-2xl border border-red-200 bg-red-50 p-6" role="alert">
      <div class="flex items-center gap-3 text-red-700">
        <AlertCircle :size="20" />

        {{ errorMessage }}
      </div>

      <button type="button" class="mt-4 text-sm font-semibold text-red-700 underline" @click="loadData">
        Reintentar
      </button>
    </div>

    <!-- GENERADOR -->

    <template v-else-if="menu && business">
      <!-- ADVERTENCIA SI NO ESTÁ PUBLICADA -->

      <div
        v-if="!menu.is_published"
        class="rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-900">
        Esta carta todavía no está publicada. Puedes preparar su QR, pero los clientes no podrán consultarla
        hasta que la publiques.
      </div>

      <MenusMenuQrGenerator
        :public-slug="business.public_slug"
        :business-id="menu.business_id"
        :slug="menu.slug"
        :restaurant-name="business.name"
        :menu-name="menu.name"
        :logo-url="business.logo_url" />
    </template>
  </div>
</template>

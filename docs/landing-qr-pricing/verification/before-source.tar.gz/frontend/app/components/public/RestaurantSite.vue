<script setup lang="ts">
import { ArrowDown, MapPin, Phone, Mail, ArrowUpRight, UtensilsCrossed } from 'lucide-vue-next';
import type { PublicSiteResponse } from '~/types/publicSite';
import { SITE_COPY } from '~/utils/publicSiteCopy';
import { publicSitePath } from '~/utils/publicUrls';
const props = defineProps<{ site: PublicSiteResponse; language: string; preview?: boolean }>();
const emit = defineEmits<{ language: [code: string] }>();
const business = computed(() => props.site.business);
const profile = computed(() => business.value.profile);
const coverUrl = computed(() => business.value.cover_url || props.site.currentMenu?.theme.branding.coverUrl);
const copy = computed(() => SITE_COPY[props.language === 'ca' ? 'val' : props.language] ?? SITE_COPY.es!);
const translated = computed(() => profile.value.translations.find(t => t.language === props.language && t.source === JSON.stringify([business.value.description ?? '', profile.value.about, business.value.default_language])));
const description = computed(() => translated.value?.description?.trim() || business.value.description);
const about = computed(() => translated.value?.about?.trim() || profile.value.about);
const address = computed(() => [profile.value.address, profile.value.postal_code, profile.value.city].filter(Boolean).join(', '));
const directions = computed(() => profile.value.maps_url || (address.value ? `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address.value)}` : ''));
const mapVisible = ref(false);
const mapUrl = computed(() => `https://www.google.com/maps?q=${encodeURIComponent([business.value.name, address.value].join(', '))}&output=embed`);
const phoneUrl = computed(() => `tel:${profile.value.phone.replace(/[^+\d]/g, '')}`);
const socialLinks = computed(() => [['Instagram',profile.value.instagram], ['Facebook',profile.value.facebook], ['TikTok',profile.value.tiktok]].filter(([,url])=>url));
const hours = computed(() => [...profile.value.hours].sort((a,b)=>a.day-b.day));
const languages = computed(() => props.site.currentMenu?.languages?.available ?? []);
const style = computed(() => {
  const hex = business.value.primary_color || '#16a34a';
  const channels = [0,2,4].map(i => parseInt(hex.slice(i+1,i+3),16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4);
  const luminance = .2126*(channels[0] ?? 0)+.7152*(channels[1] ?? 0)+.0722*(channels[2] ?? 0);
  return { '--site-primary': hex, '--site-on-primary': luminance>.179?'#111827':'#fff' };
});
</script>

<template>
  <div class="restaurant-site" :class="`site-${profile.template}`" :style="style">
    <a class="skip-link" href="#carta">{{ copy.menu }}</a>
    <nav class="site-nav" :aria-label="business.name">
      <a class="brand" href="#inicio"><img v-if="business.logo_url" :src="business.logo_url" :alt="business.name" width="36" height="36" /><span>{{ business.name }}</span></a>
      <a class="menu-cta" href="#carta">{{ copy.menu }} <ArrowDown :size="16" /></a>
    </nav>
    <main>
      <header id="inicio" class="site-hero" :class="{ 'has-photo': coverUrl }">
        <div class="hero-content">
          <img v-if="business.logo_url" class="hero-logo" :src="business.logo_url" :alt="business.name" width="64" height="64" />
          <span v-else class="hero-mark" aria-hidden="true"><UtensilsCrossed :size="24" /></span>
          <p v-if="profile.city" class="eyebrow">{{ profile.city }}</p>
          <h1>{{ business.name }}</h1>
          <p v-if="description" class="hero-description">{{ description }}</p>
          <div class="hero-actions"><a class="menu-cta" href="#carta">{{ copy.menu }} <ArrowDown :size="18" /></a><a v-if="directions" class="secondary" :href="directions" target="_blank" rel="noopener noreferrer"><MapPin :size="18" /> {{ copy.directions }}</a></div>
        </div>
        <img v-if="coverUrl" class="hero-photo" :src="coverUrl" :alt="business.name" width="1600" height="1000" fetchpriority="high" decoding="async" />
      </header>
      <!-- Menu first: restaurant information never delays access to dishes. -->
      <section id="carta" class="site-menu" :aria-label="copy.menu">
        <div class="menu-heading"><h2>{{ site.currentMenu?.menu.name || copy.menu }}</h2>
          <nav v-if="site.menus.length > 1" class="menu-tabs" :aria-label="copy.menu">
            <NuxtLink v-for="menu in site.menus" :key="menu.slug" :to="publicSitePath(business.public_slug, menu.slug, language)" :aria-current="site.currentMenu?.menu.slug === menu.slug ? 'page' : undefined">{{ menu.name }}</NuxtLink>
          </nav>
        </div>
        <PublicMenuContent v-if="site.currentMenu" :data="site.currentMenu" :language="language" embedded @language="emit('language', $event)" />
        <p v-else class="empty-menu">{{ language === 'en' ? 'Our menu will be available soon.' : language === 'fr' ? 'Notre carte sera bientôt disponible.' : language === 'val' ? 'La nostra carta estarà disponible prompte.' : 'Nuestra carta estará disponible pronto.' }}</p>
      </section>
      <section v-if="about" id="nosotros" class="site-section about-section"><p class="eyebrow">{{ business.name }}</p><h2>{{ copy.about }}</h2><p class="prose">{{ about }}</p></section>
      <section v-if="hours.length || profile.phone || profile.whatsapp || profile.email || socialLinks.length || profile.website" class="site-section info-section">
        <div v-if="hours.length"><h2>{{ copy.hours }}</h2><dl class="hours"><div v-for="day in hours" :key="day.day"><dt>{{ copy.days[day.day] }}</dt><dd>{{ day.intervals.length ? day.intervals.map(i => `${i.open} – ${i.close}`).join(' / ') : copy.closed }}</dd></div></dl></div>
        <div v-if="profile.phone || profile.whatsapp || profile.email || socialLinks.length || profile.website"><h2>{{ copy.contact }}</h2><div class="contact-links">
          <a v-if="profile.phone" :href="phoneUrl"><Phone :size="18" /> {{ profile.phone }}</a>
          <a v-if="profile.whatsapp" :href="`https://wa.me/${profile.whatsapp.replace(/\D/g, '')}`" target="_blank" rel="noopener noreferrer">WhatsApp <ArrowUpRight :size="16" /></a>
          <a v-if="profile.email" :href="`mailto:${profile.email}`"><Mail :size="18" /> {{ profile.email }}</a>
          <a v-for="[name, url] in socialLinks" :key="name" :href="url" target="_blank" rel="noopener noreferrer">{{ name }} <ArrowUpRight :size="16" /></a>
          <a v-if="profile.website" :href="profile.website" target="_blank" rel="noopener noreferrer">{{ copy.external }} <ArrowUpRight :size="16" /></a>
        </div></div>
      </section>
      <section v-if="address || directions" id="ubicacion" class="site-section location-section"><div><p class="eyebrow">{{ profile.city }}</p><h2>{{ copy.location }}</h2><address v-if="address">{{ address }}</address><a v-if="directions" class="secondary" :href="directions" target="_blank" rel="noopener noreferrer"><MapPin :size="18" />{{ copy.directions }}</a></div>
        <div v-if="profile.address" class="map-area"><iframe v-if="mapVisible" :src="mapUrl" :title="`${copy.location}: ${business.name}`" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen /><button v-else type="button" class="map-placeholder" @click="mapVisible = true"><MapPin :size="28" /><span>{{ copy.map }}</span><small>Google Maps</small></button></div>
      </section>
    </main>
    <footer class="site-footer"><span>{{ business.name }}</span><a href="https://carteliax.vercel.app" target="_blank" rel="noopener noreferrer">Powered by Carteliax</a></footer>
  </div>
</template>

<style scoped>
.restaurant-site{--site-bg:#fafaf8;--site-text:#182423;--site-muted:#52605e;--site-radius:20px;background:var(--site-bg);color:var(--site-text);font-family:Inter,system-ui,sans-serif;overflow-wrap:anywhere;min-height:100vh}
.restaurant-site *{box-sizing:border-box}.restaurant-site a{text-decoration:none;color:inherit}.restaurant-site h1,.restaurant-site h2{line-height:1.15;font-weight:700}.restaurant-site h2{font-size:clamp(1.5rem,3vw,2rem);margin:0 0 20px}.restaurant-site a:focus-visible,.restaurant-site button:focus-visible{outline:3px solid var(--site-primary);outline-offset:4px}.skip-link{position:fixed;left:12px;top:-100px;z-index:50;background:#fff;padding:12px}.skip-link:focus{top:12px}.site-nav{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 16px;position:sticky;top:0;z-index:20;background:var(--site-bg);border-bottom:1px solid #18242315;min-height:69px}.brand{display:flex;align-items:center;gap:10px;min-width:0;font-weight:700;font-size:14px}.brand span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:42vw}.brand img{object-fit:contain;flex-shrink:0;border-radius:8px}.menu-cta,.secondary{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:44px;padding:12px 16px;border-radius:10px;font-weight:650;font-size:14px}.restaurant-site .menu-cta{background:var(--site-primary);color:var(--site-on-primary);flex-shrink:0}.secondary{border:1px solid #18242330;background:var(--site-bg)}.site-hero{max-width:1180px;margin:auto;display:grid;gap:24px;padding:28px 16px}.hero-logo{object-fit:contain;margin-bottom:16px;border-radius:12px}.hero-mark{display:inline-flex;color:var(--site-primary);margin-bottom:14px}.eyebrow{font-size:12px;text-transform:uppercase;letter-spacing:.15em;color:var(--site-muted);margin:0 0 12px}.site-hero h1{font-size:clamp(2rem,6vw,4.4rem);margin:0;max-width:760px}.hero-description{max-width:570px;font-size:16px;line-height:1.65;color:var(--site-muted);margin:16px 0}.hero-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:20px}.hero-photo{width:100%;height:180px;object-fit:cover;border-radius:var(--site-radius)}.site-menu{max-width:1180px;margin:0 auto 28px;background:#fff;border:1px solid #18242315;border-radius:var(--site-radius);overflow:hidden;scroll-margin-top:80px}.menu-heading{padding:24px 16px 8px}.menu-heading h2{margin-bottom:12px}.menu-tabs{display:flex;flex-wrap:wrap;gap:6px}.menu-tabs a{min-height:44px;padding:12px 16px;background:#f1f5f4;border-radius:8px;font-size:14px}.menu-tabs a[aria-current]{background:var(--site-primary);color:var(--site-on-primary);font-weight:700}.empty-menu{padding:16px 24px 32px;color:var(--site-muted)}.site-section{max-width:1180px;margin:auto;padding:40px 20px;border-top:1px solid #18242315}.prose{white-space:pre-line;line-height:1.85;max-width:760px;color:var(--site-muted)}.info-section{display:grid;gap:36px}.hours{margin:0;max-width:480px}.hours>div{display:flex;justify-content:space-between;gap:12px;padding:12px 0;border-bottom:1px solid #18242315;font-size:14px}.hours dd{margin:0;text-align:right;color:var(--site-muted)}.contact-links{display:flex;flex-wrap:wrap;gap:10px}.contact-links a{display:inline-flex;align-items:center;gap:10px;min-height:44px;padding:12px 14px;border:1px solid #18242325;border-radius:8px;max-width:100%;font-size:14px}.location-section{display:grid;gap:24px}.location-section address{font-style:normal;line-height:1.8;color:var(--site-muted);margin:0 0 20px}.map-area iframe,.map-placeholder{width:100%;height:260px;border:0;border-radius:var(--site-radius)}.map-placeholder{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;background:#e9efeb;color:#334740;cursor:pointer;font:inherit}.map-placeholder small{font-size:12px}.site-footer{display:flex;flex-wrap:wrap;justify-content:space-between;gap:16px;padding:28px 20px;max-width:1180px;margin:auto;font-size:12px;color:var(--site-muted)}
.site-elegant{--site-bg:#181b21;--site-text:#faf7ed;--site-muted:#c1c2c5;--site-radius:4px}.site-elegant h1,.site-elegant h2{font-family:Georgia,serif;font-weight:400}.site-elegant .site-hero{padding-top:40px}.site-elegant .secondary,.site-elegant .contact-links a{border-color:#ffffff55}.site-elegant .site-section{border-color:#ffffff25}.site-elegant .site-menu{color:#182423}.site-elegant .hero-photo{filter:saturate(.8)}
.site-minimal{--site-bg:#fff;--site-radius:0px}.site-minimal .hero-logo,.site-minimal .hero-mark{display:none}.site-minimal .site-hero h1{font-weight:500;letter-spacing:-.045em}.site-minimal .site-menu{border-width:1px 0}.site-minimal .menu-cta,.site-minimal .secondary{border-radius:2px}.site-minimal .hero-photo{height:140px}
.site-classic{--site-bg:#f6f0e4;--site-text:#382c20;--site-muted:#695843;--site-radius:6px}.site-classic h1,.site-classic h2{font-family:Georgia,serif}.site-classic .hero-content{text-align:center}.site-classic .hero-actions{justify-content:center}.site-classic .hero-description{margin-left:auto;margin-right:auto}.site-classic .site-menu{border-top:4px double #8a7353}.site-classic .hero-photo{border:6px solid #fff;box-shadow:0 8px 20px #382c2015}
@media(min-width:768px){.site-nav{padding:12px max(24px,calc((100vw - 1140px)/2))}.site-hero{padding:44px 24px;align-items:center}.site-hero.has-photo{grid-template-columns:1fr 1fr;gap:40px}.hero-photo{height:340px}.site-minimal .hero-photo{height:260px}.site-section{padding:56px 24px}.info-section{grid-template-columns:1fr 1fr}.location-section{grid-template-columns:1fr 1.3fr;align-items:center}.menu-heading{padding:28px 24px 12px}.site-menu{margin-bottom:44px}.site-classic .site-hero.has-photo{grid-template-columns:1fr}.site-classic .hero-photo{height:220px}.site-classic .hero-content{max-width:780px;margin:auto}}
@media(max-width:374px){.site-nav{gap:8px;padding:10px 12px}.brand img{display:none}.brand span{max-width:39vw}.site-nav .menu-cta{padding:12px;font-size:13px}.hero-actions .secondary{font-size:13px}.site-hero h1{font-size:30px}}
/* Four identities, one shared restaurant and menu renderer. */
.site-modern{--site-bg:#f0f4ec;--site-text:#253d31;--site-muted:#566951;--site-radius:18px}.site-modern .site-nav{background:#fcfdf9}.site-modern .site-hero h1{letter-spacing:-.055em;font-weight:700}.site-modern .hero-photo{box-shadow:0 10px 25px #253d310d}.site-modern .site-menu{border-color:#dbe5d5}.site-modern .menu-heading{background:#f9fbf5}.site-modern .site-section{border-color:#dbe5d5}.site-modern .hero-mark{background:#e0eadb;padding:12px;border-radius:14px}
.site-elegant{--site-bg:#1c2622;--site-text:#f8f4e8;--site-muted:#ccd0c3;--site-radius:3px}.site-elegant .site-nav{background:#1c2622;border-bottom-color:#ffffff25}.site-elegant .site-hero h1{letter-spacing:-.03em}.site-elegant .eyebrow{letter-spacing:.2em;font-size:10px}.site-elegant .hero-photo{border:1px solid #c1b78f66;padding:7px}.site-elegant .site-menu{border:0}.site-elegant .menu-heading{background:#f5f1e6;border-bottom:1px solid #e1d9c6}.site-elegant .contact-links a{border-radius:0}.site-elegant .site-footer{border-top:1px solid #ffffff25}
.site-minimal{--site-text:#28312c;--site-muted:#5d675f}.site-minimal .site-nav{padding-block:10px;border-bottom-color:#e3e7df}.site-minimal .site-hero h1{font-size:clamp(28px,5vw,54px);font-weight:500;letter-spacing:-.05em}.site-minimal .hero-photo{filter:saturate(.7)}.site-minimal .menu-heading{padding-bottom:14px;border-bottom:1px solid #e3e7df}.site-minimal .contact-links a{border-radius:0;border-width:0 0 1px;padding-inline:0;margin-right:16px}.site-minimal .site-section{padding-block:36px}
.site-classic{--site-bg:#f7f0e3;--site-text:#493a28;--site-muted:#756147;--site-radius:6px}.site-classic .site-nav{border-bottom:3px double #c8b48e;background:#fbf7ee}.site-classic .site-hero h1{font-weight:400;letter-spacing:-.035em}.site-classic .hero-mark{border:1px solid #c8b48e;border-radius:50%;padding:12px}.site-classic .eyebrow{font-size:10px;letter-spacing:.2em}.site-classic .menu-heading{text-align:center;background:#fcf9f1;border-bottom:1px solid #e7ddcb}.site-classic .menu-tabs{justify-content:center}.site-classic .site-section{border-top:3px double #dfd0b5}.site-classic .menu-cta{border-radius:4px}
@media(max-width:767px){.site-hero{padding:22px 16px;gap:16px}.site-hero.has-photo{grid-template-columns:minmax(0,1fr) 88px;align-items:start}.hero-logo,.hero-mark{display:none}.site-hero h1,.site-minimal .site-hero h1{font-size:28px;line-height:1.13}.hero-description{font-size:14px;line-height:1.6;margin:10px 0}.site-hero .eyebrow{font-size:9px;margin-bottom:8px}.hero-photo,.site-minimal .hero-photo{width:88px;height:122px;border-radius:8px;object-fit:cover}.hero-actions{margin-top:12px;gap:8px}.hero-actions .menu-cta{display:none}.hero-actions .secondary{font-size:12px;padding:10px 12px;min-height:44px}.site-menu{margin-inline:12px;margin-bottom:24px;border-radius:12px}.menu-heading{padding:19px 16px 8px}.menu-heading h2{font-size:20px}.site-section{padding:30px 18px}.site-section h2{font-size:23px}.prose{font-size:14px;line-height:1.8}.site-classic .site-hero.has-photo{grid-template-columns:minmax(0,1fr) 88px}.site-classic .hero-content{text-align:left}.site-classic .hero-actions{justify-content:flex-start}.site-classic .hero-photo{border:3px solid #fff}.site-minimal .site-menu{margin-inline:0;border-radius:0}.site-elegant .site-menu{border-radius:3px}.site-footer{padding-block:22px}.menu-tabs a{font-size:12px;padding:11px 13px}.site-nav .menu-cta{font-size:12px}}
@media(min-width:768px){.site-hero{padding-block:38px}.site-modern .site-hero.has-photo{grid-template-columns:1.1fr .9fr}.site-elegant .site-hero.has-photo{grid-template-columns:.9fr 1.1fr}.site-elegant .hero-photo{height:310px}.site-classic .site-hero.has-photo{grid-template-columns:1fr;gap:22px}.site-classic .hero-photo{height:160px;max-width:820px;justify-self:center}.site-classic .site-hero h1{font-size:56px}.site-minimal .site-hero{padding-block:30px}.site-minimal .hero-photo{height:240px}}
</style>
